﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WPFDiagram.Model.Controls;

namespace WPFDiagram.ViewModel
{
    public class ImageViewModel: BaseControlsViewModel<ImageModel>
    {
        #region Ctor
        public ImageViewModel(ImageModel model)
            : base(model)
        {

        }
        #endregion

        #region Properties
        public String ImageName
        {
            get { return Model.ImageName; }
            set { Model.ImageName = value; OnPropertyChanged("ImageName"); }
        }

        private Boolean _isResizingEnabled = false;
        public Boolean IsResizingEnabled
        {
            get { return _isResizingEnabled; }
            set { _isResizingEnabled = value; }
        }
        #endregion
    }
}
