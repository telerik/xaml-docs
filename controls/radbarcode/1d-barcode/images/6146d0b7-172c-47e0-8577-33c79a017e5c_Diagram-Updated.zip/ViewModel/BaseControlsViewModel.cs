﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Telerik.Windows.Controls.Diagrams.Extensions.ViewModels;
using WPFDiagram.Interfaces;
using WPFDiagram.Model;
using System.Windows;

namespace WPFDiagram.ViewModel
{
    public class BaseControlsViewModel : INotifyPropertyChanged
    {
        #region Ctor
        public BaseControlsViewModel(object model)
        {
            ObjModel = model;
        }
        #endregion
        #region Properties
        public virtual Object ObjModel { get; private set; }
        #endregion


        #region INotifyPropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;

        // Create the OnPropertyChanged method to raise the event 
        protected void OnPropertyChanged(string name)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(name));
            }
        }
        #endregion
    }

    public class BaseControlsViewModel<T> :  BaseControlsViewModel where T : IControl
    {
        #region Ctor
        public BaseControlsViewModel(T model):
            base(model)
        {
            Model = model;
            Position = new Point(Model.PosX, Model.PosY);
        }
        #endregion

        #region Properties
        public  T Model { get; private set; }

        private Point _position;

        public Point Position
        {
            get { return _position; }
            set
            {
                _position = value;
                Model.PosX = Position.X;
                Model.PosY = Position.Y;
                OnPropertyChanged("Position");
            }
        }

        public Double Width
        {
            get { return Model.Width; }
            set { Model.Width = value; OnPropertyChanged("Width"); }
        }

        public Double Height
        {
            get { return Model.Height; }
            set { Model.Height = value; OnPropertyChanged("Height"); }
        }
        #endregion
    }
}
