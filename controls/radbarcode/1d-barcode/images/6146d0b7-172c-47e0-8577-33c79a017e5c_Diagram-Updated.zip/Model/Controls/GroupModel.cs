﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFDiagram.Model.Controls
{
    [Serializable]
    public class GroupModel : BaseControlsModel
    {
        #region Ctor
        public GroupModel()
            : base()
        {
            Header = String.Empty;
            Nodes = new List<BaseControlsModel>();
        }
        #endregion

        #region Properties
        public String Header { get; set; }
        public List<BaseControlsModel> Nodes { get; set; }
        #endregion
    }
}
