﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using Telerik.Windows.Controls;
using Telerik.Windows.Controls.Diagrams.Extensions.ViewModels;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using WPFDiagram.Behaviors;
using System.Collections.ObjectModel;
using WPFDiagram.Model.Controls;
using WPFDiagram.ViewModel;
using WPFDiagram.Model;


namespace WPFDiagram
{
    public class MainWindowViewModel : ViewModelBase
    {
        #region Ctor
        public MainWindowViewModel(List<BaseControlsModel> lstModel)
        {
            ZoomAllCommand = new DelegateCommand<Object>(OnZoomAll);

            ChangeImageCommand = new DelegateCommand<Object>(OnChangeImage);
            SaveCommand = new DelegateCommand<Object>(OnSave);

            Model = lstModel;

            Items = new MyGraph();

            foreach (BaseControlsModel elem in lstModel)
            {
                if (elem is ButtonModel)
                {
                    Items.AddNode(new ButtonViewModel((ButtonModel)elem));
                }
                else if (elem is ImageModel)
                {
                    Items.AddNode(new ImageViewModel((ImageModel)elem));
                }
                else if (elem is TextBoxModel)
                {
                    Items.AddNode(new TextBoxViewModel((TextBoxModel)elem));
                }
                else if (elem is LabelModel)
                {
                    Items.AddNode(new LabelViewModel((LabelModel)elem));
                }
                else if (elem is ComboBoxModel)
                {
                    Items.AddNode(new ComboBoxViewModel((ComboBoxModel)elem));
                }
                else if (elem is GroupModel)
                {
                    Items.AddNode(new GroupViewModel((GroupModel)elem));
                }
            }

            this._items.InternalItems.CollectionChanged += InternalItems_CollectionChanged;
        }

        void InternalItems_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            ;
        }
        #endregion

        #region Properties

        public static bool IsUserDeletingContainer { get; set; }

        private List<BaseControlsModel> Model;

        private MyGraph _items;

        public MyGraph Items
        {
            get { return _items; }
            set { _items = value; OnPropertyChanged("Items"); }
        }

        private Object _selectedElement;

        public Object SelectedElement
        {
            get { return _selectedElement; }
            set
            {
                _selectedElement = value;

                if (_selectedElement != null)
                {
                    //Console.Write(String.Format("X : {0} Y : {1} W : {2} H : {3}", SelectedElement.Position.X, SelectedElement.Position.Y, SelectedElement.Width, SelectedElement.Height));

                    if (_selectedElement is ButtonViewModel) Console.Write("Button Name : " + (_selectedElement as ButtonViewModel).BtnName);
                    if (_selectedElement is ImageViewModel) Console.Write("Image Name : " + (_selectedElement as ImageViewModel).ImageName);

                }

                OnPropertyChanged("SelectedElement");
            }
        }

        private ObservableCollection<Object> _selectedElements = new ObservableCollection<object>();

        public ObservableCollection<Object> SelectedElements
        {
            get { return _selectedElements; }
            set
            {
                _selectedElements = value;
                OnPropertyChanged("SelectedElements");
            }
        }

        private Boolean _snapOn = true;

        public Boolean SnapOn
        {
            get { return _snapOn; }
            set { _snapOn = value; OnPropertyChanged("SnapOn"); }
        }

        private Double _snapX = 4;

        public Double SnapX
        {
            get { return _snapX; }
            set
            {
                _snapX = value;
                OnPropertyChanged("SnapX");

                UpdateSnap();
            }
        }

        private Double _snapY = 4;

        public Double SnapY
        {
            get { return _snapY; }
            set { _snapY = value; OnPropertyChanged("SnapY"); UpdateSnap(); }
        }

        private void UpdateSnap()
        {
            CellSize = new Size(SnapX, SnapY);
        }

        private Size _cellSize = new Size(4, 4);

        public Size CellSize
        {
            get { return _cellSize; }
            set { _cellSize = value; OnPropertyChanged("CellSize"); }
        }

        private Boolean _isGridOn = true;
        public Boolean IsGridOn
        {
            get { return _isGridOn; }
            set { _isGridOn = value; OnPropertyChanged("IsGridOn"); }
        }

        private Double _lcdWidth = 240;
        public Double LcdWidth
        {
            get { return _lcdWidth; }
            set { _lcdWidth = value; OnPropertyChanged("LcdWidth"); UpdatePageSize(); }
        }

        private Double _lcdHeight = 128;
        public Double LcdHeight
        {
            get { return _lcdHeight; }
            set { _lcdHeight = value; OnPropertyChanged("LcdHeight"); UpdatePageSize(); }
        }

        private void UpdatePageSize()
        {
            PageSize = new Size(LcdWidth, LcdHeight);

            if (Md != null) Md.DragAllowedArea = new Rect(0, 0, PageSize.Width, PageSize.Height);
        }

        private Size _pageSize = new Size(240, 128);
        public Size PageSize
        {
            get { return _pageSize; }
            set { _pageSize = value; OnPropertyChanged("PageSize"); }
        }


        private MyDragging _md;

        public MyDragging Md
        {
            get { return _md; }
            set { _md = value; OnPropertyChanged("Md"); }
        }
        #endregion

        #region Commands
        /// <summary>
        /// Command for Zoom to maximum extention
        /// </summary>
        public DelegateCommand<Object> ZoomAllCommand { get; private set; }
        private void OnZoomAll(Object e)
        {
            RadDiagram rd = e as RadDiagram;

            if (rd == null) return;

            Double Coeff = rd.ActualWidth / LcdWidth;
            Double h = LcdHeight * Coeff;
            Double MustReduceOf = (rd.ActualHeight < h) ? h - rd.ActualHeight : 0.0;

            if (MustReduceOf > 0.0) Coeff -= ((Coeff * MustReduceOf) / h);

            rd.BringIntoView(new Point(0, 0), Coeff);
        }

        public DelegateCommand<Object> ChangeImageCommand { get; private set; }
        private void OnChangeImage(Object e)
        {
            if (SelectedElement != null)
            {
                if (SelectedElement is ImageViewModel)
                {
                    (SelectedElement as ImageViewModel).ImageName = "C:\\Users\\crossi\\Desktop\\PROVE DIAGRAMS\\NUOVO TELERIK\\IMAGES\\ShowGridlines.png";
                }
            }
        }


        /// <summary>
        /// Command per salvare su file
        /// </summary>
        public DelegateCommand<Object> SaveCommand { get; private set; }
        private void OnSave(Object e)
        {
            Console.WriteLine(Model.Count);



            Display a = new Display()
            {
                FileVersion = 0,
                FileType = FileTypes.NewPanel,
                VVersion = 1,
                VRelease = 0,
                StartupPage = 1,
                SelfCloseTime = 10,

                LstStr = new List<ResStr>() 
                { 
                    new ResStr() 
                    {
                        Id = 1,
                        Text = "RISORSA TESTO 1"
                    },

                    new ResStr() 
                    {
                        Id = 2,
                        Text = "RISORSA TESTO 2"
                    },
                },
                LstImg = new List<ResImg>() 
                { 
                    new ResImg()
                    {
                        Id = 1,
                        Img = new byte[] { 1 ,2 ,3 ,4 }
                    },
                    new ResImg()
                    {
                        Id = 2,
                        Img = new byte[] { 5 ,6 ,7 ,8 }
                    }
                },
                LstMu = new List<UnitConv>()
                {
                    new UnitConv() { Id = 1 , A = 1 , B = 0 , C = 2,  MuImperial = "°F" , MuSI = "°C"},
                    new UnitConv() { Id = 2 , A = 1 , B = 1 , C = 4,  MuImperial = "PSI" , MuSI = "Bar"},
                },
                LstScript = new List<Script>()
                {
                    new Script() 
                    { 
                        Id = 1 , 
                        Code = "return = a + b" , 
                        RetType = VarType.INT16 , 
                        LstPar = new List<ScriptPar>()
                        {
                            new ScriptPar() { ParName = "a", Type =  VarType.INT16 , Const = null , VarName = "Pressure"},
                            new ScriptPar() { ParName = "b", Type =  VarType.INT16 , Const = "4" , VarName = null},
                        }
                    }
                },
                LstVars = new List<Var>() 
                { 
                    new Var() 
                    { 
                        Name = "Pressure",
                        Type = VarType.INT16,
                        Access = AccessType.R ,
                        MuId= 1,
                        MW = 4,
                    },
                    new Var() 
                    { 
                        Name = "Giornalieri",
                        Type = VarType.FIX_ARY,
                        Access = AccessType.RW,
                        MW = 12,
                        LstIdx = new List<int>() { 10 },
                        Members = new List<SubVar>()
                        {
                            new SubVar()
                            {
                                Name = "StruGiorn",
                                Type = VarType.STRUCT,
                                Members = new List<SubVar>()
                                {
                                    new SubVar()
                                    {
                                        Name = "DaOra",
                                        Type = VarType.UINT8,
                                    },
                                    new SubVar()
                                    {
                                        Name = "AOra",
                                        Type = VarType.UINT8,
                                    },
                                }
                            }
                        }
                    },
                },
                LstPages = new List<Page>()
                {
                    new Page()
                    {
                        Id = 1,
                        Width = 128,
                        Height = 64,
                        SelfCloseTime = 0,
                        PasswordLevel = 1,
                        RequestPasswordBeforeOpenPage = true,

                        Controls = (from c in Model
                                        select c
                                        ).ToList<Object>()

                        //Controls = new List<object>()
                        //{
                        //    new ButtonModel()
                        //    {
                        //        BtnName = "btn1",
                        //        Height = 30,
                        //        Width = 40,
                        //        PosX = 10,
                        //        PosY = 20,
                        //    },

                        //    new LabelModel()
                        //    {
                        //        Height = 50,
                        //        Width = 50,
                        //        PosX = 0,
                        //        PosY = 0,
                        //        Text = "Label Ciao"
                        //    }
                        //}
                    }
                }
            };

            Serializations.SerializeToXML(a, "c:\\prova.xml", true);
        }
        #endregion
    }
}
