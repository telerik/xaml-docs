﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Interactivity;
using Telerik.Windows.Controls;

namespace WPFDiagram.Behaviors
{
    public class RadDiagramMultiSelectBehavior : Behavior<RadDiagram>
    {
        private RadDiagram Diagram
        {
            get
            {
                return AssociatedObject as RadDiagram;
            }
        }

        public INotifyCollectionChanged SelectedItems
        {
            get { return (INotifyCollectionChanged )GetValue(SelectedItemsProperty); }
            set { SetValue(SelectedItemsProperty, value); }
        }

        // Using a DependencyProperty as the backing store for SelectedItems.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty SelectedItemsProperty =
            DependencyProperty.Register("SelectedItems", typeof(INotifyCollectionChanged ), typeof(RadDiagramMultiSelectBehavior), new PropertyMetadata(OnSelectedItemsPropertyChanged));


        private static void OnSelectedItemsPropertyChanged(DependencyObject target, DependencyPropertyChangedEventArgs args)
        {
            var collection = args.NewValue as INotifyCollectionChanged;
            if (collection != null)
            {
                Transfer(((RadDiagramMultiSelectBehavior)target).Diagram.SelectedItems as IList, ((RadDiagramMultiSelectBehavior)target).SelectedItems as IList);
            }
        }


        protected override void OnAttached()
        {
            base.OnAttached();

            Diagram.SelectionChanged -= Diagram_SelectionChanged;
            Diagram.SelectionChanged += Diagram_SelectionChanged;
        }

        void Diagram_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            Transfer(Diagram.SelectedItems as IList, SelectedItems as IList);
        }

        public static void Transfer(IList source, IList target)
        {
            if (source == null || target == null) return;

            try
            {
                target.Clear();

                foreach (var o in source)
                {
                    target.Add(o);
                }
            }
            catch (Exception)
            {

            }
        } 
    }

}
