﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using WPFDiagram.Interfaces;
using WPFDiagram.Model.Controls;

namespace WPFDiagram.Model
{
    /// <summary>
    /// Main class for Display
    /// </summary>
    [Serializable]
    [XmlInclude(typeof(BaseControlsModel)),
     XmlInclude(typeof(ButtonModel)),
     XmlInclude(typeof(ComboBoxModel)),
     XmlInclude(typeof(GroupModel)),
     XmlInclude(typeof(ImageModel)),
     XmlInclude(typeof(LabelModel)),
     XmlInclude(typeof(TextBoxModel)),
    ]
    public class Display : IVersion , IVersioning
    {
        #region Ctor
        public Display()
        {
            FileVersion = 0;
            FileType = FileTypes.Unknown;
            VVersion = 1;
            VRelease = 0;

            StartupPage = 0;
            SelfCloseTime = 0;

            LstVars = null;
            LstStr = null;
            LstImg = null;
            LstMu = null;
            LstScript = null;
            LstPages = null;

        }
        #endregion

        #region Properties
        /// <summary>
        /// Version of the file
        /// </summary>
        public int FileVersion { get; set; }
        /// <summary>
        /// Type of file
        /// </summary>
        public FileTypes FileType { get; set; }

        /// <summary>
        /// Version of the application
        /// </summary>
        public byte VVersion { get; set; }
        /// <summary>
        /// Release of the application
        /// </summary>
        public byte VRelease { get; set; }

        /// <summary>
        /// Startup page number
        /// </summary>
        public int StartupPage { get; set; }

        /// <summary>
        /// Self closure time [s]
        /// 0 = Never Close
        /// This parameter can be overridden by the same paraeter in single pages
        /// </summary>
        public UInt32 SelfCloseTime { get; set; }

        /// <summary>
        /// List of Variables
        /// </summary>
        public List<Var> LstVars { get; set; }
        
        /// <summary>
        /// List of String Resources
        /// </summary>
        public List<ResStr> LstStr { get; set; }

        /// <summary>
        /// List of Image Resources
        /// </summary>
        public List<ResImg> LstImg { get; set; }

        /// <summary>
        /// List o Conversion functions
        /// </summary>
        public List<UnitConv> LstMu { get; set; }

        /// <summary>
        /// List of script
        /// </summary>
        public List<Script> LstScript { get; set; }

        /// <summary>
        /// List of Pages
        /// </summary>
        public List<Page> LstPages { get; set; }

        #endregion
    }
}
