﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFDiagram.Model
{
    [Serializable]
    public class SubVar
    {
        #region Ctor
        public SubVar()
        {
            Name = null;
            Type = VarType.UNKNOWN;
            StringLen = 0;
            LstIdx = null;
            LstVarIdx = null;
            MuId = 0;
            MinValue = null;
            MaxValue = null;
            UseInvalid = false;
            Members = null;
        }
        #endregion
        #region Properties
        /// <summary>
        /// Variabile Name
        /// </summary>
        public String Name { get; set; }

        /// <summary>
        /// Variabile type
        /// </summary>
        public VarType Type { get; set; }

        /// <summary>
        /// Used by Strings
        /// </summary>
        public int StringLen { get; set; }

        /// <summary>
        /// List fixed index vars
        /// </summary>
        public List<int> LstIdx { get; set; }

        /// <summary>
        /// List variable length index vars
        /// </summary>
        public List<String> LstVarIdx { get; set; }

        /// <summary>
        /// Id for Measure Unit
        /// </summary>
        public int MuId { get; set; }

        /// <summary>
        /// MinValue for Editing
        /// </summary>
        public float? MinValue { get; set; }

        /// <summary>
        /// MaxValue for Editing
        /// </summary>
        public float? MaxValue { get; set; }

        /// <summary>
        /// Use Invalid for value
        /// </summary>
        public Boolean UseInvalid { get; set; }



        /// <summary>
        /// Member's list
        /// </summary>
        public List<SubVar> Members { get; set; }
        #endregion
    }
}
