﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using Telerik.Windows.Controls;
using Telerik.Windows.Diagrams.Core;

namespace WPFDiagram
{
    public class MyDragging : DraggingService // , INotifyPropertyChanged
    {
        private readonly RadDiagram diagram;
        private Point lastPoint;

        public MyDragging(RadDiagram graph)
            : base(graph as IGraphInternal)
        {
            this.DragAllowedArea = Rect.Empty;
            this.diagram = graph;
        }

//        public event PropertyChangedEventHandler PropertyChanged;

        public Rect DragAllowedArea { get; set; }

        public override void InitializeDrag(Point point)
        {
            this.lastPoint = point;
            base.InitializeDrag(point);
        }

        public override void Drag(Point newPoint)
        {
            Point dragPoint = newPoint;

            var selectionBounds = this.GetSelectionBounds();
            var offset = new Vector(newPoint.X - this.lastPoint.X, newPoint.Y - this.lastPoint.Y);
            var newBounds = new Rect(selectionBounds.X + offset.X, selectionBounds.Y + offset.Y, selectionBounds.Width, selectionBounds.Height);

            if (this.DragAllowedArea == Rect.Empty || this.DragAllowedArea.Contains(newBounds))
            {
                base.Drag(newPoint);
                this.lastPoint = dragPoint;
                return;
            }

            if (this.DragAllowedArea.Left > newBounds.Left)
                dragPoint = new Point(dragPoint.X - (newBounds.Left - this.DragAllowedArea.Left), dragPoint.Y);
            else if (this.DragAllowedArea.Right < newBounds.Right)
                dragPoint = new Point(dragPoint.X - (newBounds.Right - this.DragAllowedArea.Right), dragPoint.Y);

            if (this.DragAllowedArea.Top > newBounds.Top)
                dragPoint = new Point(dragPoint.X, dragPoint.Y - (newBounds.Top - this.DragAllowedArea.Top));
            else if (this.DragAllowedArea.Bottom < newBounds.Bottom)
                dragPoint = new Point(dragPoint.X, dragPoint.Y - (newBounds.Bottom - this.DragAllowedArea.Bottom));

            base.Drag(dragPoint);
            this.lastPoint = dragPoint;
        }

        private Rect GetSelectionBounds()
        {
            Rect result = Rect.Empty;
            foreach (var item in this.diagram.SelectedItems)
            {
                var container = this.diagram.ContainerGenerator.ContainerFromItem(item);
                var shape = item as IShape;
                if (shape != null)
                    result.Union(shape.ActualBounds);
                else
                    result.Union(container.Bounds);
            }

            return result;
        }
    }
}
