﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFDiagram.Model
{
    [Serializable]
    public class ResImg
    {
        #region Ctor
        public ResImg()
        {
            Id = 0;
            Img = null;
        }
        #endregion

        #region Properties
        public Int32 Id { get; set; }

        /// <summary>
        /// Array of bytes of a bmp file
        /// </summary>
        public byte[] Img { get; set; }
        #endregion
    }
}
