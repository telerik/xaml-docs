﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFDiagram.Model
{
    public enum VarType
    {
        UNKNOWN = 0,
        BOOL = 1,
        INT8 = 2,
        UINT8 = 3,
        INT16 = 4,
        UINT16 = 5,
        INT32 = 6,
        UINT32 = 7,
        INT64 = 8,
        UINT64 = 9,
        REAL32 = 10,
        REAL64 = 11,
        STRING = 12,
        STRUCT = 13,
        TIME = 14,
        DATE = 15,
        FIX_ARY = 16,  // Fixed Length array
        VAR_ARY = 17,  // Variable Length array
    }
}
