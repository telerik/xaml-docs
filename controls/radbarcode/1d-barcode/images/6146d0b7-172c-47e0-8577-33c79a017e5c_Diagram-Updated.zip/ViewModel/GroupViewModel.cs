﻿using System;
using System.Collections;
using System.Collections.Specialized;
using System.Linq;
using Telerik.Windows.Diagrams.Core;
using WPFDiagram.Model.Controls;
using System.Collections.ObjectModel;

namespace WPFDiagram.ViewModel
{
    public class GroupViewModel : BaseControlsViewModel<GroupModel>, IContainerItem
    {
        #region Ctor
        public GroupViewModel(GroupModel model) : base(model)
        {
            _nodes = new ObservableCollection<BaseControlsViewModel>();

            foreach (BaseControlsModel elem in model.Nodes)
            {
                if (elem is ButtonModel)
                {
                    this._nodes.Add(new ButtonViewModel((ButtonModel)elem));
                }
                else if (elem is ImageModel)
                {
                    this._nodes.Add(new ImageViewModel((ImageModel)elem));
                }
                else if (elem is TextBoxModel)
                {
                    this._nodes.Add(new TextBoxViewModel((TextBoxModel)elem));
                }
                else if (elem is LabelModel)
                {
                    this._nodes.Add(new LabelViewModel((LabelModel)elem));
                }
                else if (elem is ComboBoxModel)
                {
                    this._nodes.Add(new ComboBoxViewModel((ComboBoxModel)elem));
                }
                else if (elem is GroupModel)
                {
                    this._nodes.Add(new GroupViewModel((GroupModel)elem));
                }
            }
            this.PropertyChanged += GroupViewModel_PropertyChanged;
            _nodes.CollectionChanged += Nodes_CollectionChanged;
        }
 
        private void Nodes_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            if (e.Action == NotifyCollectionChangedAction.Remove && MainWindowViewModel.IsUserDeletingContainer)
            {
                //the user deletes a container. this is why the children shapes of the container are removed from the deleted container itself
                ;
                MainWindowViewModel.IsUserDeletingContainer = false;
            }
        }

        void GroupViewModel_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            ;
        }

        public bool AddItem(object item)
        {
            this._nodes.Add((BaseControlsViewModel)item);
            Model.Nodes.Add(((BaseControlsViewModel)item).ObjModel as BaseControlsModel);
            return true;
        }

        public bool RemoveItem(object item)
        {
            Model.Nodes.Remove(((BaseControlsViewModel)item).ObjModel as BaseControlsModel);
            return this._nodes.Remove((BaseControlsViewModel)item);
        }

        public IEnumerable Items
        {
            get { return this._nodes; }
        }




        //public bool AddItem(object item)
        //{
        //    this._nodes.Add((BaseControlsViewModel)item);
        //    return true;
        //}

        //public bool RemoveItem(object item)
        //{
        //    return this._nodes.Remove((BaseControlsViewModel)item);
        //}

        //public IEnumerable Items
        //{
        //    get { return this._nodes; }
        //}

        //void Nodes_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        //{
        //    switch (e.Action)
        //    {
        //        case System.Collections.Specialized.NotifyCollectionChangedAction.Add:
        //            foreach (BaseControlsModel item in e.NewItems)
        //            {
        //                Model.Nodes.Add(item);
        //            }
        //            break;

        //        case System.Collections.Specialized.NotifyCollectionChangedAction.Remove:
        //            foreach (BaseControlsModel item in e.OldItems)
        //            {
        //                Model.Nodes.Remove(item);
        //            }
        //            break;

        //        case System.Collections.Specialized.NotifyCollectionChangedAction.Move:
        //            foreach (BaseControlsModel item in e.OldItems)
        //            {
        //                Model.Nodes.RemoveAt(e.OldStartingIndex);
        //                Model.Nodes.Insert(e.NewStartingIndex, item);
        //            }
        //            break;

        //        case System.Collections.Specialized.NotifyCollectionChangedAction.Reset:
        //            Model.Nodes.Clear();
        //            break;
        //    }
        //}

        #endregion

        #region Properties
        public String Header
        {
            get { return Model.Header; }
            set { Model.Header = value; OnPropertyChanged("Header"); }
        }

        private ObservableCollection<BaseControlsViewModel> _nodes;
        //public ObservableCollection<BaseControlsViewModel> Nodes
        //{
        //    get { return _nodes; }
        //    set 
        //    { 
        //        _nodes = value;
        //        OnPropertyChanged("Nodes");
        //    }
        //}

        private Boolean _isResizingEnabled = true;
        public Boolean IsResizingEnabled
        {
            get { return _isResizingEnabled; }
            set { _isResizingEnabled = value; }
        }        
        #endregion
    }
}