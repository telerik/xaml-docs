﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WPFDiagram.Interfaces;

namespace WPFDiagram.Model.Controls
{
    [Serializable]
    public class BaseControlsModel : IControl
    {
        #region Ctor
        public BaseControlsModel()
        {
            PosX = 0;
            PosY = 0;
            Width = 0;
            Height = 0;
        }
        #endregion

        #region Properties
        public Double PosX { get; set; }
        public Double PosY { get; set; }
        public Double Width { get; set; }
        public Double Height { get; set; }
        #endregion
    }
}
