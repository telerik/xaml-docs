﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFDiagram.Model.Controls
{
    [Serializable]
    public class ComboBoxModel: BaseControlsModel 
    {
        #region Ctor
        public ComboBoxModel()
            : base()
        {
            LstIndex = -1;
        }
        #endregion

        #region Properties
        public Int32 LstIndex { get; set; }
        #endregion
    }
}