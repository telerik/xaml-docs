﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFDiagram.Interfaces
{
    public interface IVersioning
    {
        Byte VVersion { get; set; }
        Byte VRelease { get; set; }
    }
}
