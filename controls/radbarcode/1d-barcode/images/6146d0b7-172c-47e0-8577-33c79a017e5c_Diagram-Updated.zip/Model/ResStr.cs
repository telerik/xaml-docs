﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFDiagram.Model
{
    /// <summary>
    /// String resources
    /// </summary>
    [Serializable]
    public class ResStr
    {
        #region Ctor
        public ResStr()
        {
            Id = 0;
            Text = String.Empty;
        }
        #endregion

        #region Properties
        public Int32 Id { get; set; }
        public String Text { get; set; }
        #endregion
    }
}
