﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFDiagram.Interfaces
{
    public interface IControl
    {
        Double PosX { get; set; }
        Double PosY { get; set; }
        Double Width { get; set; }
        Double Height { get; set; }
    }
}
