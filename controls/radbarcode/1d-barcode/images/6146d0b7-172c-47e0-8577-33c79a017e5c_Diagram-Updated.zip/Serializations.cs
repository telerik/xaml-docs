﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace WPFDiagram
{
    public class Serializations
    {

        /// <summary>
        /// Funzione per serializzare un oggetto su file tramite XML
        /// </summary>
        /// <param name="obj">Oggetto da serializzare</param>
        /// <param name="strNomeFile">Nome del file su cui scrivere</param>
        /// <param name="cutEmptyTags">True = Toglie i Tag Vuoti/False = Non tagliare i Tag Vuoti</param> 
        /// <returns></returns>
        public static Boolean SerializeToXML(object obj, String strNomeFile, Boolean cutEmptyTags)
        {
            try
            {
                XmlSerializer xmls = new XmlSerializer(obj.GetType());

                MemoryStream ms = new MemoryStream();
                xmls.Serialize(ms, obj);

                SaveXML(ms, strNomeFile, cutEmptyTags);
                ms.Close();

                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Coster Error 'SerializeToXML' : " + ex.Message + "\n" + ex.StackTrace); 
                throw ex;
            }
        }

        /// <summary>
        /// Funzione per salvare un memorystream con i dati xml su file
        /// </summary>
        /// <param name="ms">Memorystream contenente l'XML</param>
        /// <param name="fileName">Nome del file su cui salvare</param>
        /// <param name="cutEmptyTags">True = Toglie i Tag Vuoti/False = Non tagliare i Tag Vuoti</param>
        private static void SaveXML(MemoryStream ms, String fileName, Boolean cutEmptyTags)
        {
            String s = Encoding.UTF8.GetString(ms.ToArray());

            XmlDocument xmlDocument = new XmlDocument();
            xmlDocument.LoadXml(s);

            if (cutEmptyTags)
            {
                // Se devo togliere i Nodi vuoti
                XmlNodeList emptyElements = xmlDocument.SelectNodes(@"//*[not(node())]");

                for (int i = emptyElements.Count - 1; i > -1; i--)
                {
                    XmlNode nodeToBeRemoved = emptyElements[i];
                    nodeToBeRemoved.ParentNode.RemoveChild(nodeToBeRemoved);
                }
            }
            xmlDocument.Save(fileName);
        }

    }
}
