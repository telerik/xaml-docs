﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFDiagram.Model
{
    public enum FileTypes
    {
        Unknown = 0,
        NewPanel = 1,
    }
}
