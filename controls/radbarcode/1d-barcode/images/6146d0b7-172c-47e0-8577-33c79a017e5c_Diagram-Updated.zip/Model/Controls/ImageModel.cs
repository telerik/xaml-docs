﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFDiagram.Model.Controls
{
    [Serializable]
    public class ImageModel : BaseControlsModel
    {
        #region Ctor
        public ImageModel() : base()
        {
            ImageName = String.Empty;
        }
        #endregion

        #region Properties
        public String ImageName { get; set; }
        #endregion
    }
}
