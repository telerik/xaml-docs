﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WPFDiagram.Model.Controls;

namespace WPFDiagram.ViewModel
{
    public class ButtonViewModel : BaseControlsViewModel<ButtonModel>
    {
        #region Ctor
        public ButtonViewModel(ButtonModel model)
            : base(model)
        {

        }
        #endregion

        #region Properties


        public String BtnName
        {
            get { return Model.BtnName; }
            set { Model.BtnName = value; OnPropertyChanged("BtnName"); }
        }

        private Boolean _isResizingEnabled = true;
        public Boolean IsResizingEnabled
        {
            get { return _isResizingEnabled; }
            set { _isResizingEnabled = value; }
        }
        #endregion
    }
}
