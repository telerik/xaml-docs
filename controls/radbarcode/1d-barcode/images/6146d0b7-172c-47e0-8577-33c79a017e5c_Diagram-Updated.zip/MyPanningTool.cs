﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using Telerik.Windows.Diagrams.Core;

namespace WPFDiagram
{
    public class MyPanningTool : PanningTool
    {
        private Point startPoint;
        private Rect startViewport;

        public Rect PanAllowedArea { get; set; }

        public override bool MouseDown(PointerArgs e)
        {
            this.startViewport = this.Graph.Viewport;
            this.startPoint = e.Point;
            return base.MouseDown(e);
        }

        public override bool MouseMove(PointerArgs e)
        {
            if (this.IsActive)
            {
                var diffX = (this.startPoint.X - e.Point.X);
                var diffY = (this.startPoint.Y - e.Point.Y);

                diffX = Math.Min(diffX, (this.PanAllowedArea.Right - this.startViewport.Right) * this.Graph.Zoom);
                diffX = Math.Max(diffX, (this.PanAllowedArea.Left - this.startViewport.Left) * this.Graph.Zoom);

                diffY = Math.Min(diffY, (this.PanAllowedArea.Bottom - this.startViewport.Bottom) * this.Graph.Zoom);
                diffY = Math.Max(diffY, (this.PanAllowedArea.Top - this.startViewport.Top) * this.Graph.Zoom);

                e.Point = new Point(this.startPoint.X - diffX, this.startPoint.Y - diffY);
            }

            return base.MouseMove(e);
        }
    }
}
