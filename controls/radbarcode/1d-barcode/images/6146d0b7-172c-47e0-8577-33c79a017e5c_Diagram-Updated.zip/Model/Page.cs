﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFDiagram.Model
{
    [Serializable]
    public class Page
    {
        #region Ctor
        public Page()
        {
            Id = 0;
            Width = 128;
            Height = 64;
            PasswordLevel = 0;
            RequestPasswordBeforeOpenPage = true;
            SelfCloseTime = 0;
            Controls = null;
        }
        #endregion

        #region Properties
        /// <summary>
        /// Page Id
        /// </summary>
        public Int32 Id { get; set; }

        /// <summary>
        /// Page Width
        /// </summary>
        public Int32 Width { get; set; }

        /// <summary>
        /// Page Height
        /// </summary>
        public Int32 Height { get; set; }

        /// <summary>
        /// Password level (0 = lowest / 4 = Maximum)
        /// </summary>
        public UInt16 PasswordLevel { get; set; }

        /// <summary>
        /// True = request password before opening the page
        /// </summary>
        public Boolean RequestPasswordBeforeOpenPage { get; set; }

        /// <summary>
        /// Self closure time [s]
        /// 0 = use the SelfCloseTime parameter of the Display Class
        /// </summary>
        public UInt32 SelfCloseTime { get; set; }

        /// <summary>
        /// Controls handled
        /// </summary>
        public List<Object> Controls { get; set; }

        #endregion
    }
}