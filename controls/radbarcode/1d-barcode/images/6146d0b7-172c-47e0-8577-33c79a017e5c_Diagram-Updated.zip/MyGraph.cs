﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Telerik.Windows.Controls.Diagrams.Extensions.ViewModels;

namespace WPFDiagram
{
    public class MyGraph : ObservableGraphSourceBase<Object, LinkViewModelBase<NodeViewModelBase>>
    {
        public override bool RemoveItem(object node)
        {
            return base.RemoveItem(node);
        }
        public override void AddNode(object node)
        {
            base.AddNode(node);
        }
    }
}
