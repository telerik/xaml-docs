﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFDiagram.Model
{
    /// <summary>
    /// Lista accesso ai dati supportati
    /// </summary>
    public enum AccessType
    {
        R = 0,
        W = 1,
        RW = 2
    }
}
