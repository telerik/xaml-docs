﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WPFDiagram.Model;

namespace WPFDiagram.Interfaces
{
    public interface IVersion
    {
        int FileVersion { get; set; }
        FileTypes FileType { get; set; }
    }
}
