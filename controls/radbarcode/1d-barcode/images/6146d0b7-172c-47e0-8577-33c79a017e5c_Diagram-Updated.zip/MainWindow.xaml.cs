﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Telerik.Windows.Controls;
using Telerik.Windows.Diagrams.Core;
using Telerik.Windows.Controls.Extensions;
using Telerik.Windows.Controls.Diagrams;
using WPFDiagram.Model.Controls;
using WPFDiagram.ViewModel;

namespace WPFDiagram
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Rect lcdArea = new Rect(0, 0, 240, 128);
        private double lastZoomChange = 1.0;

        private List<BaseControlsModel> LstModel;

        public MainWindow()
        {
            InitializeComponent();

            DiagramConstants.MinimumZoom = 1;

            LstModel = new List<BaseControlsModel>()
            {
                //new ButtonModel() { PosX = 0 , PosY = 0 , Width = 40 , Height = 64 , BtnName = "Btn A"},
                //new ButtonModel() { PosX = 40 , PosY = 0 , Width = 40 , Height = 64 , BtnName = "Btn B"},
                //new ImageModel() { PosX = 80 , PosY = 64 , Width = 40 , Height = 64 , ImageName = "Images/Cooling.png"},
                //new ImageModel() { PosX = 120 , PosY = 64 , Width = 40 , Height = 64 , ImageName = "Images/FanSpeed1.png"},
                //new ImageModel() { PosX = 120 , PosY = 0 , Width = 40 , Height = 64 , ImageName = "Images/FanSpeed2.png"},
                //new ImageModel() { PosX = 120 , PosY = 0 , Width = 40 , Height = 64 , ImageName = "Images/UP.png"},
                //new ImageModel() { PosX = 120 , PosY = 0 , Width = 40 , Height = 64 , ImageName = "Images/DOWN.png"},
                //new ImageModel() { PosX = 120 , PosY = 0 , Width = 40 , Height = 64 , ImageName = "Images/RIGHT.png"},
                //new TextBoxModel() { PosX = 40 , PosY = 0 , Width = 80 , Height = 20 , Text = "Claudio"},
                new LabelModel() { PosX = 40 , PosY = 50 , Width = 80 , Height = 20 , Text = "Mia Label"}, 
                new ComboBoxModel() { PosX = 0 , PosY = 0 , Width = 80 , Height = 20 , LstIndex = 4},
                //new GroupModel() { PosX = 0 , PosY = 0 , Width = 100 , Height = 80 , Header = "Group"},

            };

            GroupModel gp = new GroupModel() { PosX = 0, PosY = 0, Width = 100, Height = 80, Header = "MainGroup" };
            gp.Nodes.Add(new ButtonModel() { PosX = 0, PosY = 0, Width = 40, Height = 40, BtnName = "Ciao" });
            LstModel.Add(gp);

            MainWindowViewModel VM = new MainWindowViewModel(LstModel);

            VM.Md = new MyDragging(this.diagram);
//            var pan = new MyPanningTool();
                                                                                                                                                                                                                        
            VM.Md.DragAllowedArea = lcdArea;
            
//            pan.PanAllowedArea = lcdArea;

            // Set ViewModel
            this.DataContext = VM;

            this.diagram.ServiceLocator.Register<IDraggingService>(VM.Md);
            diagram.ItemsChanging += diagram_ItemsChanging;
        }

        void diagram_ItemsChanging(object sender, DiagramItemsChangingEventArgs e)
        {
            if (e.Action == System.Collections.Specialized.NotifyCollectionChangedAction.Remove)
            {
                var objectToDelete = e.OldItems.FirstOrDefault() as GroupViewModel;
                if (objectToDelete != null)
                {
                    MainWindowViewModel.IsUserDeletingContainer = true;
                }
            }
        }

        private void diagram_ZoomChanged(object sender, Telerik.Windows.RadRoutedPropertyChangedEventArgs<double> e)
        {
            this.lastZoomChange = e.NewValue / e.OldValue;
            double factor = e.NewValue;
            this.backgroundRect.RenderTransformOrigin = new Point(0, 0);
            this.backgroundRect.RenderTransform = new ScaleTransform() { ScaleX = factor, ScaleY = factor };
        }

        private void diagram_ViewportChanged(object sender, PropertyEventArgs<Rect> e)
        {
            if (Canvas.GetLeft(this.backgroundRect).Equals(double.NaN))
            {
                Canvas.SetLeft(this.backgroundRect, 0);
                Canvas.SetTop(this.backgroundRect, 0);
                return;
            }

            var transformedPoint = this.diagram.GetTransformedPoint(new Point());
            var newPos = new Point(-transformedPoint.X * this.diagram.Zoom, -transformedPoint.Y * this.diagram.Zoom);

            Canvas.SetLeft(this.backgroundRect, newPos.X);
            Canvas.SetTop(this.backgroundRect, newPos.Y);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            diagram.AutoFit();
        }

        private void diagram_CommandExecuted(object sender, CommandRoutedEventArgs e)
        {
            if (e.Command == DiagramCommands.Delete)
            {
                
            }
        }
    }
}
