﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFDiagram.Model
{
    [Serializable]
    public class Script
    {
        #region Ctor
        public Script()
        {
            Id = 0;
            Code = null;
            LstPar = null;
            RetType = VarType.UNKNOWN;
        }
        #endregion

        #region Properties
        public Int32 Id { get; set; }

        public String Code { get; set; }

        /// <summary>
        /// Lista di tipi di parametri per lo script
        /// </summary>
        public List<ScriptPar> LstPar { get; set; }

        /// <summary>
        /// Tipo ritornato dalla funzione
        /// </summary>
        public VarType RetType { get; set; }
        #endregion
    }
}
