﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFDiagram.Model.Controls
{
    [Serializable]
    public class TextBoxModel : BaseControlsModel 
    {
        #region Ctor
        public TextBoxModel()
            : base()
        {
            Text = String.Empty;
        }
        #endregion

        #region Properties
        public String Text { get; set; }
        #endregion
    }
}
