﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFDiagram.Model.Controls
{
    [Serializable]
    public class ButtonModel : BaseControlsModel 
    {
        #region Ctor
        public ButtonModel() : base()
        {
            BtnName = String.Empty;
        }
        #endregion

        #region Properties
        public String BtnName { get; set; }
        #endregion
    }
}
