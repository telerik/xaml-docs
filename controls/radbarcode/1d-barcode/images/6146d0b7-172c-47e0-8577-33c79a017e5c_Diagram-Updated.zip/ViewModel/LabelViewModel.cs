﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WPFDiagram.Model.Controls;

namespace WPFDiagram.ViewModel
{
    public class LabelViewModel : BaseControlsViewModel<LabelModel>
    {
        #region Ctor
        public LabelViewModel(LabelModel model)
            : base(model)
        {

        }
        #endregion

        #region Properties
        public String Text
        {
            get { return Model.Text; }
            set { Model.Text = value; OnPropertyChanged("Text"); }
        }

        private Boolean _isResizingEnabled = true;
        public Boolean IsResizingEnabled
        {
            get { return _isResizingEnabled; }
            set { _isResizingEnabled = value; }
        }
        #endregion
    }
}