﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFDiagram.Model
{
    [Serializable]
    public class ScriptPar
    {
        #region Ctor
        public ScriptPar()
        {
            ParName = null;
            Const = null;
            Const = null;
            VarName = null;
        }
        #endregion

        #region Properties
        /// <summary>
        /// Name of the parameter
        /// </summary>
        public String ParName { get; set; }

        /// <summary>
        /// Parameter type
        /// </summary>
        public VarType Type { get; set; }

        /// <summary>
        /// Null = const not used
        /// </summary>
        public String Const { get; set; }


        /// <summary>
        /// != null = Use var name like parameter
        /// </summary>
        public String VarName { get; set; }
        #endregion
    }
}
