﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFDiagram.Model
{
    [Serializable]
    public class Var : SubVar
    {
        #region Ctor
        public Var()
            : base()
        {
            MW = 0;
            Access = AccessType.RW;
        }
        #endregion

        #region Properties
        /// <summary>
        /// Starting MW
        /// </summary>
        public int MW { get; set; }

        /// <summary>
        /// R/W/RW
        /// </summary>
        public AccessType Access { get; set; }
        #endregion
    }
}
