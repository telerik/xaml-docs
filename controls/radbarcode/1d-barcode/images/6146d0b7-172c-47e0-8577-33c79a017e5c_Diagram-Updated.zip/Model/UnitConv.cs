﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFDiagram.Model
{
    [Serializable]
    public class UnitConv
    {
        #region Ctor
        public UnitConv()
        {
            Id = 0;
            MuSI = null;
            MuImperial = null;
            A = null;
            B = null;
            C = null;
        }
        #endregion

        #region Properties
        /// <summary>
        /// Page Id
        /// </summary>
        public Int32 Id { get; set; }

        /// <summary>
        /// Measure unit for International system
        /// </summary>
        public String MuSI { get; set; }

        /// <summary>
        /// Measure unit for Imperial system
        /// </summary>
        public String MuImperial { get; set; }

        [DefaultValueAttribute(null)]
        public int? A { get; set; }
        [DefaultValueAttribute(null)]
        public int? B { get; set; }
        [DefaultValueAttribute(null)]
        public int? C { get; set; }
        #endregion
    }
}
